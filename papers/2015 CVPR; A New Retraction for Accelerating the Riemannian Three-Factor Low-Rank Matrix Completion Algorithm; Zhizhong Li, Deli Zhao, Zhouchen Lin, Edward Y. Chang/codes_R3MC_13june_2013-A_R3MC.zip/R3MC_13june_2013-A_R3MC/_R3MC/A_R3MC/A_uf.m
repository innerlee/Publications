function [A B] = A_uf(A)
    % Extract the orthogonal factor of a matrix A
    % uf(A) = A (A'*A)^(-0.5)
    
    % Refer "R3MC: A Riemannian three-factor algorithm for low-rank matrix completion",
    % B. Mishra and R. Sepulchre,
    % Technical report, arXiv:1306.2672, 2013.
    % This implementation is due to
    % Bamdev Mishra <b.mishra@ulg.ac.be>, 2013
  
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file is modified by Zhizhong Li for the A-R3MC algorithm
% Refer "A New Retraction for Accelerating the Riemannian Three-Factor Low-Rank Matrix Completion Algorithm"
% lizz@pku.edu.cn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [L, S, R] = svd(A, 0);
    A = L*R';
    B = R * S * R';
end