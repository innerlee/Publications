addpath('Mex_files/');
addpath(genpath('_R3MC'));
addpath('Auxiliary_files/');