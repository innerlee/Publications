cd Mex_files

% Extracting a subset of entries of a matrix 
mex partXY.c

% Update a sparse matrix 
mex updateSparse.c

cd ..


