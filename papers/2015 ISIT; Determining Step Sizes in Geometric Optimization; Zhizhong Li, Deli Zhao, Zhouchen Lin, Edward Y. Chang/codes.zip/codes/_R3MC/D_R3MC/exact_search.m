function [xt,ft, succ,numf,iarm] = exact_search(model, dir, data_ls,tl,tr,n)

% Exact ('numerically exact') line search on an interval with fminbnd.

% xc, current point
% fc = F(sys,xc)
% gc is search direction
%
% returns: xt,ft: local minimum point and F(sys,xt)
%          succ = true if success
%          numf: nb of F evals
%          iarm: nb of Armijo backtrackings

opts.MaxIter = 100;
opts.TolX = 1e-10;



%tr = tr*1e5;

%ts = linspace(0,tr,500);
%fs = fun(sys,ts,xc,gc);
%semilogy(ts,fs,'.')
%pause
    function ft = fun(alpha)
        [model_mid.U] = uf(model.U + alpha*dir.U);
        [model_mid.V] = uf(model.V + alpha*dir.V);
        model_mid.R = model.R + alpha*dir.R; % ORIGINAL retraction
        
        preds_ls = partXY((model_mid.U * model_mid.R)', model_mid.V', data_ls.rows, data_ls.cols, n)';
        errors = (preds_ls - data_ls.entries);
        
        ft =(2/n)* 0.5*(errors'*errors);% + 0.5*gamma*norm(model_mid.R,'fro')^2;
    end

[xt,ft,flag,output] = fminbnd(@fun,tl,tr,opts);
if flag == 1
    succ = true;
else
    succ = false;
end
numf = output.funcCount;
iarm = output.iterations;

end